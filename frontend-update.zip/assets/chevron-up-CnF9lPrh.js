import{w as o}from"./index-BpSnE-rP.js";const e=[["path",{d:"m18 15-6-6-6 6",key:"153udz"}]],n=o("chevron-up",e);export{n as C};
