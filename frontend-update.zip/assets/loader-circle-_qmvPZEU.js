import{w as e}from"./index-DuOF99at.js";const o=[["path",{d:"M21 12a9 9 0 1 1-6.219-8.56",key:"13zald"}]],a=e("loader-circle",o);export{a as L};
